import { StyleSheet } from 'react-native';

export const COLORS = {
  background: "#0A0A0A",    // Preto (Fundo Principal)
  primaryRed: "#8B0000",    // Vermelho Escuro (Cor de Destaque Primária)
  accentRed: "#A02020",     // Carmesim (Usado para Bordas, Brilho e Gradientes)
  darkGray: "#2A2A2A",      // Cinza Escuro (Fundo de Cartões e Elementos Secundários)
  textLight: "#CFCFCF",     // Cinza Quase Branco (Texto Principal)
  textMedium: "#A3A3A3",    // Cinza Médio (Subtítulos, detalhes)
};

export const SPACING = {
  padding: 20,
  margin: 10,
  borderRadius: 15,
};

// Estilo de sombra vermelho escuro para o tema
export const SHADOW_STYLES = StyleSheet.create({
  redGlow: {
    shadowColor: COLORS.primaryRed,
    shadowOpacity: 0.6,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 10,
    elevation: 5,
  },
});