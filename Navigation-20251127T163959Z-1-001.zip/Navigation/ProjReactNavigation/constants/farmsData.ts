import { ImageSourcePropType } from 'react-native';

// Importa o tipo de rota do Expo Router para garantir a tipagem correta
import { type Route } from 'expo-router';

// Tipos para os dados da Farm
export interface Farm {
  number: number;
  title: string;
  description: string;
  image: ImageSourcePropType;
  youtubeLink: string;
  // Rotas tipadas para garantir a navegação
  nextRoute: Route | '/'; 
  prevRoute: Route | '/';
}

// =================================================================
// NOTA IMPORTANTE:
// É essencial que os arquivos das imagens (farm5.jpg, farm4.jpg, etc.)
// estejam realmente no caminho '../assets/images/'.
// Caso contrário, você terá um erro de "require".
// =================================================================

export const FARMS: Record<string, Farm> = {
  // TOP 5: Volta para a Home, Próxima é a Farm 4
  farm5: {
    number: 5,
    title: "Farm de Ferro (A Fonte Inesgotável)",
    description: "Uma das farms clássicas e mais essenciais para qualquer mundo, esta farm de Golems de Ferro garante um suprimento constante de um dos materiais mais valiosos do jogo.",
    image: require("@/assets/images/farm5.jpeg"),
    youtubeLink: "https://youtu.be/ZrX5KR96KwM?si=RuVHP38SRJCzfuof",
    prevRoute: "/", // Volta para a página inicial
    nextRoute: "/farm4",
  },
  
  // TOP 4: Próxima é a Farm 3, Anterior é a Farm 5
  farm4: {
    number: 4,
    title: "Farm de Ouro (A Usina de XP e Ouro)",
    description: "Utilizando portais do Nether e Piglins, esta farm não só gera ouro em grandes quantidades, mas também se destaca como uma das melhores fontes de experiência.",
    image: require("../assets/images/farm4.jpg"),
    youtubeLink: "https://youtu.be/1ORcsVBVDNo?si=ywU0o2CB-paOn2fp",
    prevRoute: "/farm5",
    nextRoute: "/farm3",
  },

  // TOP 3: Próxima é a Farm 2, Anterior é a Farm 4
  farm3: {
    number: 3,
    title: "Farm de Lã (Coloração Automática)",
    description: "A Sheep Tower é um design engenhoso que permite a colheita automatizada de lã de todas as cores, essencial para quem busca grandes construções ou decorações.",
    image: require("../assets/images/farm3.jpg"),
    youtubeLink: "https://youtu.be/TNE7D968zBA?si=-bPKJKmkYO0-fV0P",
    prevRoute: "/farm4",
    nextRoute: "/farm2",
  },
  
  // TOP 2: Próxima é a Farm 1, Anterior é a Farm 3
  farm2: {
    number: 2,
    title: "Farm de Guardiões (O Monstro de XP)",
    description: "Construída em um Templo do Oceano, esta farm aproveita os Guardiões para gerar uma quantidade absurda de XP e blocos de Prisma, sendo crucial para a fase final do jogo.",
    image: require("../assets/images/farm2.jpg"),
    youtubeLink: "https://youtu.be/Z6RDWWfgweo?si=XoUD7ip4C9KRpjnW",
    prevRoute: "/farm3",
    nextRoute: "/farm1",
  },
  
  // TOP 1: Próxima é a Home, Anterior é a Farm 2
   farm1: {
    number: 1,
    title: "A ILHA SLIME (Monstro do Nether)",
    description: "Uma construção épica no Nether que elimina a necessidade de Slime Chunks. Ela utiliza um gerador de monstros ou Golems para invocar Slimes na camada de bedrock, garantindo uma produção massiva, eficiente e constante de slimeballs e blocos de slime.",
    image: require("@/assets/images/farm1.jpg"),
    youtubeLink: "https://youtu.be/NrgqsR9I_Ac?si=k9g6zH01eZkkOXGO",
    prevRoute: "/farm2",
    nextRoute: "/", // Volta para a página inicial
  },
};