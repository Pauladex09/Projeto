import HomeScreenUI from "@/components/HomeScreenUI";
import React from 'react';

// Este arquivo de rota é agora extremamente limpo, apenas ligando
// o caminho "/" ao componente visual HomeScreenUI.
export default function Home() {
  return <HomeScreenUI />;
}