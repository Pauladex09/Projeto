import FarmScreenUI from "@/components/FarmScreenUI";
import { FARMS } from "@/constants/farmsData";

// Dados da Farm 4
const farmData = FARMS.farm4;

export default function Farm4Screen() {
  return (
    <FarmScreenUI 
      number={farmData.number}
      title={farmData.title}
      description={farmData.description}
      image={farmData.image}
      youtubeLink={farmData.youtubeLink}
      prevFarmRoute={farmData.prevRoute} 
      nextFarmRoute={farmData.nextRoute} 
    />
  );
}