import FarmScreenUI from "@/components/FarmScreenUI";
import { FARMS } from "@/constants/farmsData";

// Dados da Farm 3
const farmData = FARMS.farm3;

export default function Farm3Screen() {
  return (
    <FarmScreenUI 
      number={farmData.number}
      title={farmData.title}
      description={farmData.description}
      image={farmData.image}
      youtubeLink={farmData.youtubeLink}
      prevFarmRoute={farmData.prevRoute} 
      nextFarmRoute={farmData.nextRoute} 
    />
  );
}