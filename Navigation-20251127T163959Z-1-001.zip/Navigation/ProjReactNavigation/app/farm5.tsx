import FarmScreenUI from "@/components/FarmScreenUI";
import { FARMS } from "@/constants/farmsData";

// Dados da Farm 5
const farmData = FARMS.farm5;

export default function Farm5Screen() {
  return (
    <FarmScreenUI 
      number={farmData.number}
      title={farmData.title}
      description={farmData.description}
      image={farmData.image}
      youtubeLink={farmData.youtubeLink}
      prevFarmRoute={farmData.prevRoute} 
      nextFarmRoute={farmData.nextRoute} 
    />
  );
}