import React, { useEffect, useRef } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image, Animated, Dimensions } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
// Importando o SidebarButton
import SidebarButton from './SidebarButton';

// --- Configurações de Dimensões ---
const { width, height } = Dimensions.get("window");

// Largura da imagem de fundo
const IMG_WIDTH_RATIO = 1.8; 
const PANORAMA_WIDTH = width * IMG_WIDTH_RATIO;

const COLORS = {
  backgroundDark: "#0A0A0A",    // Preto (Fundo Principal e Card)
  neonAqua: "#8B0000",          // Vermelho Escuro (Usado para Destaque)
  textLight: "#CFCFCF",         // Cinza Quase Branco (Usado para Texto Principal)
  grayMedium: "#A3A3A3",       
  border: "#ce0000ff",           
};

// Estilos de sombra para aplicar no card e no botão
const SHADOW_STYLES = StyleSheet.create({
  redGlow: {
    shadowColor: COLORS.neonAqua,
    shadowOpacity: 0.7,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 15,
    elevation: 8,
  },
});

export default function HomeScreenUI() {
  // Corrigido para usar useRef: garante que o valor animado seja persistente
  const scrollX = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Inicia a animação em loop
    Animated.loop(
      Animated.timing(scrollX, {
        toValue: PANORAMA_WIDTH,
        duration: 15000,
        useNativeDriver: true,
      })
    ).start();
    
    // Cleanup function: opcional, mas boa prática para interromper animação se o componente desmontar
    return () => scrollX.stopAnimation();
  }, [scrollX]); 

  const translateX = scrollX.interpolate({
    inputRange: [0, PANORAMA_WIDTH],
    outputRange: [0, -PANORAMA_WIDTH],
  });

  return (
    <View style={styles.container}>
      
      {/* Botão de Menu Lateral: Posição fixa no canto superior direito */}
      <View style={styles.sidebarButtonContainer}>
          <SidebarButton />
      </View>

      {/* ===== FUNDO ANIMADO ===== */}
      <Animated.View style={[styles.bgWrapper, { transform: [{ translateX }] }]}>
        {/* Duas imagens lado a lado para o loop perfeito */}
        {/* RESTAURADO: Usando sua imagem bg-minecraft.png */}
        <Image 
          source={require("../assets/images/bg-minecraft.png")} 
          style={styles.panoramaImage} 
        />
        <Image 
          source={require("../assets/images/bg-minecraft.png")} 
          style={styles.panoramaImage} 
        />
      </Animated.View>

      <LinearGradient colors={["#000000AA", "#00000033", "#000000AA"]} style={styles.overlay} />

      {/* ===== CONTEÚDO ===== */}
      <View style={[styles.contentBox, SHADOW_STYLES.redGlow]}>
        <Ionicons name="trophy" size={60} color={COLORS.neonAqua} style={styles.glow} />

        {/* Título */}
        <Text style={styles.title}>Top 5 Farms de Minecraft</Text>
        <Text style={styles.subtitle}>do Viniccius13</Text>

        {/* Navega para a primeira farm do ranking */}
        <TouchableOpacity style={styles.buttonWrapper} onPress={() => router.push("/farm5")}>
          <LinearGradient 
                // Degradê do botão: Vermelho Escuro (neonAqua) para Preto (backgroundDark)
                colors={[COLORS.neonAqua, COLORS.backgroundDark]} 
                start={{ x: 0, y: 0 }}
                end={{ x: 0, y: 1 }}
                style={styles.buttonGradient}
            >
            <Ionicons name="rocket" size={24} color={COLORS.textLight} /> 
            {/* Texto ajustado para branco/claro (textLight) */}
            <Text style={styles.buttonText}>VER TOP 5 FARMS</Text>
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: COLORS.backgroundDark,
    overflow: "hidden",
  },
  
  // Estilo para posicionar o botão de menu
  sidebarButtonContainer: {
    position: 'absolute',
    top: 60, // Posição no topo
    right: 20,
    zIndex: 10, // Garante que fique acima de outros elementos
  },

  // ===== FUNDO PANORÂMICO =====
  bgWrapper: {
    position: "absolute",
    flexDirection: "row",
    width: PANORAMA_WIDTH * 2, // Duas vezes a largura da imagem
    height: height,
    top: 0,
    left: 0,
  },

  panoramaImage: {
    width: PANORAMA_WIDTH,
    height: height,
    resizeMode: "cover", // Garante que a imagem preencha a altura total
  },

  overlay: {
    ...StyleSheet.absoluteFillObject,
  },

  // ===== CONTEÚDO =====
  contentBox: {
    width: "85%",
    paddingVertical: 70,
    paddingHorizontal: 25,
    // Fundo do Card ajustado para preto semitransparente (0A0A0A com 80% de opacidade)
    backgroundColor: COLORS.backgroundDark + 'CC', 
    borderRadius: 25,
    borderWidth: 2, // Aumentei a borda para destacar
    borderColor: COLORS.neonAqua, // Borda vermelha
    alignItems: "center",
    justifyContent: "center",
  },

  title: {
    fontSize: 36,
    color: COLORS.neonAqua, // O título principal continua vermelho para contraste
    fontWeight: "800",
    textShadowColor: COLORS.neonAqua + "88",
    textShadowRadius: 10,
    marginBottom: 10,
    textAlign: "center",
  },

  subtitle: {
    color: COLORS.textLight, // Agora branco/claro
    fontSize: 18,
    fontStyle: "italic",
    marginBottom: 40,
  },

  glow: {
    textShadowColor: COLORS.neonAqua, // Vermelho
    textShadowRadius: 18,
  },

  buttonWrapper: {
    borderRadius: 15,
    // A sombra é aplicada via SHADOW_STYLES no contentBox, mas aqui garantimos que a wrapper não corte a sombra.
    overflow: 'hidden',
  },

  buttonGradient: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingVertical: 14,
    paddingHorizontal: 35,
    borderRadius: 15,
    borderWidth: 1, // Contorno leve para destacar o degradê
    borderColor: COLORS.neonAqua + '50', 
  },

  buttonText: {
    fontSize: 18,
    fontWeight: "900",
    color: COLORS.textLight, // Agora branco/claro
    textTransform: 'uppercase',
  },
});