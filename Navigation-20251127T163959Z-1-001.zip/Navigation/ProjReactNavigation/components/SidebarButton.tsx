import React, { useState } from 'react';
import { TouchableOpacity, StyleSheet, Text, Modal, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';

// --- PALETA DE CORES DEFINIDA NO PRÓPRIO ARQUIVO ---
const COLORS = {
  backgroundDark: "#0A0A0A",    // Preto (Fundo Principal)
  neonAqua: "#8B0000",          // Vermelho Escuro (Cor de Destaque Primária)
  textLight: "#CFCFCF",         // Cinza Quase Branco (Texto Principal)
  textSubtle: "#A3A3A3",        // Cinza Médio (Subtítulos, detalhes)
  border: "#2A2A2A",            // Cinza Escuro (Fundo de Cartões e Elementos Secundários)
};

const SPACING = {
  padding: 20,
  margin: 10,
  borderRadius: 15,
};

const SHADOW_STYLES = StyleSheet.create({
  redGlow: {
    shadowColor: COLORS.neonAqua,
    shadowOpacity: 0.7,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 10,
    elevation: 8,
  },
});
// ----------------------------------------------------

// Define o tipo de rota específico para o menu, RESOLVENDO O ERRO TS2345
type AppRoute = '/' | '/farm5' | '/farm4' | '/farm3' | '/farm2' | '/farm1';

type MenuItem = {
    name: string;
    icon: keyof typeof Ionicons.glyphMap;
    route: AppRoute;
};

export default function SidebarButton() {
  const [modalVisible, setModalVisible] = useState(false);

  // Função de navegação com verificação de segurança, usando o tipo AppRoute
  const navigateTo = (route: AppRoute) => { // Tipo alterado de 'string' para 'AppRoute'
    setModalVisible(false);
    // Verifica se a rota não está vazia ou nula antes de navegar
    if (route) { 
        router.push(route);
    }
  };

  const menuItems: MenuItem[] = [ // Tipagem adicionada aqui para garantir a consistência
    { name: 'Início', icon: 'home-outline', route: '/' },
    { name: 'Farm 5', icon: 'server-outline', route: '/farm5' },
    { name: 'Farm 4', icon: 'server-outline', route: '/farm4' },
    { name: 'Farm 3', icon: 'server-outline', route: '/farm3' },
    { name: 'Farm 2', icon: 'server-outline', route: '/farm2' },
    { name: 'Farm 1', icon: 'server-outline', route: '/farm1' },
  ];

  return (
    <>
      <TouchableOpacity 
        style={[styles.menuButton, SHADOW_STYLES.redGlow]} 
        onPress={() => setModalVisible(true)}
      >
        <LinearGradient
          // Usando as constantes COLORS definidas acima
          colors={[COLORS.neonAqua, COLORS.border]}
          style={styles.menuGradient}
        >
          <Ionicons name="menu" size={24} color={COLORS.backgroundDark} />
        </LinearGradient>
      </TouchableOpacity>

      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.centeredView}>
          <View style={[styles.modalView, SHADOW_STYLES.redGlow]}>
            <Text style={styles.modalTitle}>MENU TOP 5 FARMS</Text>
            
            {menuItems.map((item) => (
              <TouchableOpacity
                key={item.name}
                style={styles.menuItem}
                onPress={() => navigateTo(item.route)}
              >
                <Ionicons name={item.icon as keyof typeof Ionicons.glyphMap} size={20} color={COLORS.neonAqua} />
                <Text style={styles.menuItemText}>{item.name}</Text>
              </TouchableOpacity>
            ))}

            <TouchableOpacity
              style={styles.closeButton}
              onPress={() => setModalVisible(false)}
            >
              <Text style={styles.closeButtonText}>FECHAR</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  menuButton: {
    borderRadius: SPACING.borderRadius,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: COLORS.neonAqua + 'AA',
  },
  menuGradient: {
    padding: 8,
  },
  
  // Estilos do Modal
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    // Cor fixa (rgba) mantida para o overlay de fundo do modal
    backgroundColor: 'rgba(0, 0, 0, 0.7)', 
  },
  modalView: {
    width: '80%',
    backgroundColor: COLORS.backgroundDark,
    borderRadius: SPACING.borderRadius * 2,
    padding: 25,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: COLORS.neonAqua,
  },
  modalTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: COLORS.neonAqua,
    marginBottom: 20,
    textShadowColor: COLORS.neonAqua + "88",
    textShadowRadius: 8,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
    gap: 15,
  },
  menuItemText: {
    color: COLORS.textLight,
    fontSize: 18,
    fontWeight: '500',
  },
  closeButton: {
    marginTop: 30,
    backgroundColor: COLORS.neonAqua,
    borderRadius: SPACING.borderRadius,
    paddingVertical: 10,
    paddingHorizontal: 30,
  },
  closeButtonText: {
    color: COLORS.backgroundDark, // Texto escuro no fundo vermelho
    fontWeight: 'bold',
    fontSize: 16,
  },
});