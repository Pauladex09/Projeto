import React from 'react';
import { TouchableOpacity, Text, StyleSheet, View } from 'react-native';
import { router, type Route } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

// --- PALETA DE CORES DEFINIDA NO PRÓPRIO ARQUIVO ---
const COLORS = {
  backgroundDark: "#0A0A0A",    // Preto (Fundo Principal)
  neonAqua: "#8B0000",          // Vermelho Escuro (Cor de Destaque Primária)
  textLight: "#CFCFCF",         // Cinza Quase Branco (Texto Principal)
  textSubtle: "#A3A3A3",        // Cinza Médio (Subtítulos, detalhes)
  border: "#2A2A2A",            // Cinza Escuro (Fundo de Cartões e Elementos Secundários)
};

const SPACING = {
  borderRadius: 15,
};

const SHADOW_STYLES = StyleSheet.create({
  redGlow: {
    shadowColor: COLORS.neonAqua,
    shadowOpacity: 0.7,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 10,
    elevation: 8,
  },
});
// ----------------------------------------------------

// Tipo de rota específico do Expo Router
type FarmRoute = Route | '/';

type FarmNavigationButtonProps = {
  direction: 'prev' | 'next';
  route: FarmRoute;
  label: string;
  iconName: keyof typeof Ionicons.glyphMap;
};

export default function FarmNavigationButton({
  direction,
  route,
  label,
  iconName,
}: FarmNavigationButtonProps) {

  // Lógica de navegação: usa 'replace' se for para a Home, senão usa 'push'
  const handlePress = () => {
    if (route === '/') {
      router.replace(route);
    } else {
      router.push(route);
    }
  };

  const isPrev = direction === 'prev';

  return (
    // Certifique-se de que a TouchableOpacity não contém texto solto
    <TouchableOpacity 
      style={[styles.buttonWrapper, SHADOW_STYLES.redGlow]} 
      onPress={handlePress}
    >
      <LinearGradient
        // Gradiente do Fundo: usa o destaque vermelho e a cor de borda
        colors={isPrev ? [COLORS.border, COLORS.neonAqua + '30'] : [COLORS.neonAqua + '30', COLORS.border]}
        start={{ x: 0, y: 0.5 }}
        end={{ x: 1, y: 0.5 }}
        style={styles.buttonGradient}
      >
        <Ionicons name={iconName} size={20} color={COLORS.neonAqua} />
        {/* O texto está DENTRO do componente <Text> */}
        <Text style={styles.buttonText}>{label}</Text>
      </LinearGradient>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  buttonWrapper: {
    flex: 1,
    borderRadius: SPACING.borderRadius,
    borderWidth: 1,
    borderColor: COLORS.neonAqua + '80', // Borda sutil de destaque
  },
  buttonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 10,
    borderRadius: SPACING.borderRadius,
    gap: 8,
  },
  buttonText: {
    color: COLORS.textLight, // Cor do texto sincronizada com o tema
    fontSize: 14,
    fontWeight: '700',
    textAlign: 'center',
  },
});