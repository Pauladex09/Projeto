import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Linking, ScrollView } from "react-native";
// Importar o tipo 'Route' para tipagem correta da navegação
import { router, type Route } from "expo-router"; 
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

// Importar os novos componentes
import FarmNavigationButton from './FarmNavigationButton';
import SidebarButton from './SidebarButton';

// NOVA PALETA: VERMELHO, PRETO E CINZA
const COLORS = {
  backgroundDark: "#0A0A0A",    // Preto (Fundo Principal)
  neonAqua: "#8B0000",          // Vermelho Escuro (Cor de Destaque Primária)
  textLight: "#CFCFCF",         // Cinza Quase Branco (Texto Principal)
  textSubtle: "#A3A3A3",        // Cinza Médio (Subtítulos, detalhes)
  border: "#2A2A2A",            // Cinza Escuro (Fundo de Cartões e Elementos Secundários)
};


type FarmScreenProps = {
  number: number;             
  title: string;              
  description: string;        
  image: any;                 
  youtubeLink: string;        // Novo: link do vídeo
  nextFarmRoute: Route | '/';     // Corrigido para o tipo Route do Expo
  prevFarmRoute: Route | '/';     // Corrigido para o tipo Route do Expo
};

export default function FarmScreenUI({ // Renomeado para UI para evitar conflito com a rota
  number,
  title,
  description,
  image,
  youtubeLink,
  nextFarmRoute,
  prevFarmRoute,
}: FarmScreenProps) {
    
  // Lógica de navegação para a farm anterior
  const handlePrev = () => {
    // Se a rota for a Home, usamos router.replace, senão usamos push
    if (prevFarmRoute === '/') {
        router.replace('/');
    } else {
        router.push(prevFarmRoute);
    }
  };

  // Lógica de navegação para a próxima farm
  const handleNext = () => {
    if (nextFarmRoute === '/') {
        router.replace('/');
    } else {
        router.push(nextFarmRoute);
    }
  };

  // Determina os labels e ícones dos botões de navegação
  const isHomePrev = prevFarmRoute === '/';
  const isHomeNext = nextFarmRoute === '/';
  
  const prevLabel = isHomePrev ? "Voltar ao Início" : `⬅ Farm ${number + 1}`;
  const nextLabel = isHomeNext ? "Voltar ao Início" : `Farm ${number - 1} ➡`;
  const prevIcon = isHomePrev ? 'home' : 'arrow-back-outline';
  const nextIcon = isHomeNext ? 'home' : 'arrow-forward-outline';


  return (
    <View style={styles.fullContainer}>
        {/* Botão de Menu Lateral (Sempre no canto superior direito) */}
        <View style={styles.sidebarButtonContainer}>
            <SidebarButton />
        </View>

        <ScrollView contentContainerStyle={styles.scrollContent}>
            <Text style={styles.title}>Top {number} - {title}</Text>

            {/* Imagem */}
            <View style={styles.imageWrapper}>
                <Image source={image} style={styles.image} resizeMode="cover" />
            </View>

            {/* Link do Youtube - AGORA USANDO GRADIENTE VERMELHO E CORES DA PALETA */}
            <TouchableOpacity 
                style={[styles.youtubeButton, styles.youtubeShadow]} // Aplica sombra vermelha
                onPress={() => Linking.openURL(youtubeLink)}
            >
                <LinearGradient
                    // Cores do gradiente: Cinza Escuro (Borda) para Vermelho Escuro (Destaque)
                    colors={[COLORS.border, COLORS.neonAqua + '50', COLORS.border]}
                    start={{ x: 0, y: 0.5 }}
                    end={{ x: 1, y: 0.5 }}
                    style={styles.youtubeGradient}
                >
                    <Ionicons name="logo-youtube" size={24} color={COLORS.neonAqua} />
                    <Text style={styles.youtubeText}>VER VÍDEO COMPLETO</Text>
                </LinearGradient>
            </TouchableOpacity>

            <Text style={styles.description}>{description}</Text>
            
            {/* Controles de Navegação */}
            <View style={styles.navigationControls}>
                <FarmNavigationButton
                    direction="prev"
                    route={prevFarmRoute}
                    label={prevLabel}
                    iconName={prevIcon}
                />
                <View style={{ width: 20 }} /> 
                <FarmNavigationButton
                    direction="next"
                    route={nextFarmRoute}
                    label={nextLabel}
                    iconName={nextIcon}
                />
            </View>
        </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  fullContainer: {
    flex: 1,
    backgroundColor: COLORS.backgroundDark,
  },
  sidebarButtonContainer: {
    position: 'absolute',
    top: 60,
    right: 20,
    zIndex: 10, // Garante que o botão fique acima de tudo
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 20,
    alignItems: "center",
    paddingBottom: 40,
  },
  title: {
    fontSize: 32,
    fontWeight: "900",
    color: COLORS.neonAqua,
    marginTop: 100, // Ajuste para o botão do menu lateral
    marginBottom: 20,
    textAlign: 'center',
    textShadowColor: COLORS.neonAqua + "88",
    textShadowRadius: 10,
  },
  imageWrapper: {
    width: "100%",
    borderRadius: 15,
    borderWidth: 2,
    borderColor: COLORS.border,
    // Sombra do destaque
    shadowColor: COLORS.neonAqua, 
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 15,
    elevation: 8,
    marginBottom: 20,
  },
  image: {
    width: "100%",
    height: 220,
    borderRadius: 12,
  },
  description: {
    color: COLORS.textSubtle,
    fontSize: 18,
    textAlign: "left",
    marginBottom: 40,
    width: '100%',
    lineHeight: 25,
  },
  // Estilo de sombra vermelha para o botão do YouTube
  youtubeShadow: {
    shadowColor: COLORS.neonAqua,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.7,
    shadowRadius: 10,
    elevation: 10,
  },
  youtubeButton: {
    borderRadius: 10,
    marginBottom: 30,
    borderWidth: 1,
    borderColor: COLORS.neonAqua + 'AA', // Borda vermelha sutil
  },
  youtubeGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 10,
    gap: 10,
  },
  youtubeText: {
    color: COLORS.textLight, // Texto padronizado (Cinza Claro)
    fontSize: 16,
    fontWeight: 'bold',
  },
  navigationControls: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    marginTop: 20,
  }
});